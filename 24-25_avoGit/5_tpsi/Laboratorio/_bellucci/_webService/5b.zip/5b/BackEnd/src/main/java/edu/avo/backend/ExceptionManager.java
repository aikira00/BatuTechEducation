/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.avo.backend;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;

/**
 * Lancia un'eccezione di tipo 500 quando qualche servizio va in errore
 * 
 * @author palma
 */
@Provider
public class ExceptionManager extends Throwable {

    public Response toResponse(Throwable ex) {
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                .entity("Errore interno del server: " + ex.getMessage())
                .build();
    }
}
