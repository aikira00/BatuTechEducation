/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.avo.backend.resources;


import edu.avo.backend.ConnectionUtility;
import edu.avo.bolibrary.Category;
import edu.avo.mysqllibrary.Server;

import edu.avo.parser.Parser;
import edu.avo.parser.ProxyObjectConverter;
import edu.avo.parser.proxies.CategoryProxy;
import jakarta.ws.rs.Consumes;

import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.NamingException;

/**
 *
 * @author palma
 */
@Path("categories")
public class Categories {

    @GET
    public Response getCategories(@QueryParam("id") String id) throws SQLException, NamingException {
        Object result;
        Connection connection = ConnectionUtility.getConnection();
        Server server = new Server(connection);
        if(id==null){
            result = server.selectCategories();
        }else{
            result=server.selectCategory(Integer.parseInt(id));
        }
        connection.close();
        return Response.ok(result, MediaType.APPLICATION_JSON).build();

    }
    
    @DELETE
    public Response deleteCategory(@QueryParam("id") String id) throws SQLException, NamingException {
        Connection connection = ConnectionUtility.getConnection();
        Server server = new Server(connection);
        int num=server.deleteCategory(Integer.parseInt(id));
        String result = "{\"deleted\":"+num+"}";
        connection.close();
        return Response.ok(result, MediaType.APPLICATION_JSON).build();
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addCategory(CategoryProxy cp) throws NamingException, SQLException{
        Connection connection = ConnectionUtility.getConnection();
        Server server = new Server(connection);
        Category category=ProxyObjectConverter.getCategory(cp);
        int num=server.insertCategory(category);
        String result = "{\"added\":"+num+"}";
        connection.close();
        return Response.ok(result, MediaType.APPLICATION_JSON).build();
    }
    
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateCategory(CategoryProxy cp) throws NamingException, SQLException{
        Connection connection = ConnectionUtility.getConnection();
        Server server = new Server(connection);
        Category category=ProxyObjectConverter.getCategory(cp);
        int num=server.updateCategory(category);
        String result = "{\"updated\":"+num+"}";
        connection.close();
        return Response.ok(result, MediaType.APPLICATION_JSON).build();
    }
}
