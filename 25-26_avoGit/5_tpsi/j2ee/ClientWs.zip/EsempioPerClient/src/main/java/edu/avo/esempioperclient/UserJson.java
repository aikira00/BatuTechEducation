/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.avo.esempioperclient;

/**
 *
 * @author MULTI01
 */
public class UserJson {
    private int id;
    private String name;
    private String surname;
    private String address;

    public UserJson() {
        id=-1;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    public User getUser(){
        User user;
        if(id==-1){
            user=new User(name, surname, address);
        }else{
            user=new User(id, name, surname, address);
        }
        return user;
    }
}
