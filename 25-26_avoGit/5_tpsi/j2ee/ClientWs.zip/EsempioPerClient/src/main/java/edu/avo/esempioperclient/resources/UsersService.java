package edu.avo.esempioperclient.resources;

import edu.avo.esempioperclient.User;
import edu.avo.esempioperclient.UserJson;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 
 */
@Path("users")
public class UsersService {
    
    @GET
    public Response selectAll(){
        List<User> list=new ArrayList();
        list.add(new User(1,"wwww","wwww","hsdgfhdfghg"));
        list.add(new User(2,"hhhh","rrrr","aaaaaaaaaaaa"));
        list.add(new User(3,"vvvv","mmm","kkkkkkk"));
        return Response
                .ok(list)
                .build();
    }
    
    @GET
    @Path("{id}")
    public Response selectOne(@PathParam("id") int id){        
        return Response
                .ok(new User(id,"vvvv","mmm","kkkkkkk"))
                .build();
    }
    
    @POST
    public Response insertOne(UserJson user){
        return Response
                .ok(user.getUser())
                .build();
    }
    @POST
    @Path("more")
    public Response insertMore(UserJson[] users){
        return Response
                .ok("ok")
                .build();
    }
    
    @PUT
    public Response update(UserJson user){
        return Response
                .ok(user.getUser())
                .build();
    }
}
