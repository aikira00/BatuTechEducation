/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.avo.clientws;

import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MULTI01
 */
public class RestClient {

    private Client client;
    private WebTarget baseTarget;
    private Jsonb jsonb;
    
    public RestClient(String baseUrl) {
        client = ClientBuilder.newClient();
        baseTarget = client.target(baseUrl);
        jsonb = JsonbBuilder.create();
    }

    public List<User> getUsers(String path) {

        Response response = baseTarget
                .path(path)
                .request(MediaType.APPLICATION_JSON)
                .get();
        //In funzione della classe
        List<User> users=new ArrayList<>();
        if (response.getStatus() == 200) {

            String json = response.readEntity(String.class);
            
            //in funzione della classe
            UserJson[] array = jsonb.fromJson(json, UserJson[].class);

            for(UserJson uj: array){
                users.add(uj.getUser());
            }
        }

        response.close();
        return users;
    }

    public User getUser(String path) {

        Response response = baseTarget
                .path(path)
                .request(MediaType.APPLICATION_JSON)
                .get();

        UserJson user = null;

        if (response.getStatus() == 200) {

            String json = response.readEntity(String.class);
            
            user = jsonb.fromJson(json, UserJson.class);
        }

        response.close();
        return user.getUser();
    }

   
    public User createUser(String path, User user) {
        Response response = baseTarget
                .path(path)
                .request(MediaType.APPLICATION_JSON)
                .post(Entity.entity(jsonb.toJson(user),MediaType.APPLICATION_JSON));

        User create = null;

        if (response.getStatus() == 201 || response.getStatus() == 200) {
            String json = response.readEntity(String.class);
            
            create = jsonb.fromJson(json, UserJson.class).getUser();
        }

        response.close();
        return create;
    }

    public User createMoreUser(String path, User[] users) {
        Response response = baseTarget
                .path(path)
                .request(MediaType.APPLICATION_JSON)
                .post(Entity.entity(jsonb.toJson(users),MediaType.APPLICATION_JSON));

        User create = null;

        if (response.getStatus() == 201 || response.getStatus() == 200) {
            String json = response.readEntity(String.class);
            
            create = jsonb.fromJson(json, UserJson.class).getUser();
        }

        response.close();
        return create;
    }

    public User updateUser(String path, User user) {

        Response response = baseTarget
                .path(path)
                .request(MediaType.APPLICATION_JSON)
                .post(Entity.entity(jsonb.toJson(user),MediaType.APPLICATION_JSON));

        User updated = null;

        if (response.getStatus() == 201 || response.getStatus() == 200) {
            String json = response.readEntity(String.class);            
            updated = jsonb.fromJson(json, UserJson.class).getUser();
        }

        response.close();
        return updated;
    }

    

    

    public void close() {
        client.close();
    }
}
