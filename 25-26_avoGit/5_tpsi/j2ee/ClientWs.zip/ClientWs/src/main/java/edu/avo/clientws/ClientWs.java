/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package edu.avo.clientws;

import java.util.List;

/**
 *
 * @author MULTI01
 */
public class ClientWs {

    public static void main(String[] args) {
        RestClient client = new RestClient("http://localhost:8080/EsempioPerClient/api/");

        //GET lista
        List<User> users = client.getUsers("users");
        for (User u: users) {
            System.out.println(u);
        }

        // GET singolo
        User u = client.getUser("users/1");
        System.out.println(u);

        // POST
        User newUser = new User("qqq","www","eeee");
        System.out.println(newUser);
        User created = client.createUser("users", newUser);

        // PUT
        created.setAddress("fdhfghggf");
        User updated =client.updateUser("users",created);
        System.out.println(updated);
        User[] array={new User("qqq","qqq","qqqq"),new User("aaaa","aaa","aaaa")};
        client.createMoreUser("users/more", array);
        client.close();
    }
}
