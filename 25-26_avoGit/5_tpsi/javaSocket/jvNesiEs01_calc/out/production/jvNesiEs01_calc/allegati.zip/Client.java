/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.es_1;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import java.util.Scanner;

/**
 *
 * @author MULTI01
 */
public class Client {
    public static void main(String[] args) throws IOException{
        try{
            Socket s = new Socket("Localhost", 7890);
            while(true){
                Scanner scanner = new Scanner(System.in);
                System.out.print("Inserisci il valore in euro: ");
                float num = scanner.nextFloat();
                //s.getOutputStream().wr
                PrintWriter out= new PrintWriter(s.getOutputStream());
                out.println(num);
                s.close();
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}