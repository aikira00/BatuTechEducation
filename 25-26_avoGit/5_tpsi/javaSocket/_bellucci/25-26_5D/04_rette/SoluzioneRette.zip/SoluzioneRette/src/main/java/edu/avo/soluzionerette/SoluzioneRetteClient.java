/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.avo.soluzionerette;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JOptionPane;

/**
 *
 * @author palma
 */
public class SoluzioneRetteClient {

    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("127.0.0.1", 60000);
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String command;
        String response = null;
        String[] abc = new String[5];
        abc[3] = "";

        String[] menu = {"Esplicita", "Ortogonale", "Parallela", "Quit"};
        while (!"Quit".equals(command = menu[JOptionPane.showOptionDialog(null, "Scegliere il comando", "Menu", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, menu, menu[0])])) {
            abc[0] = JOptionPane.showInputDialog("Inserire il coefficiente a");
            abc[1] = JOptionPane.showInputDialog("Inserire il coefficiente b");
            abc[2] = JOptionPane.showInputDialog("Inserire il coefficiente c");
            switch (command) {
                case "Ortogonale" -> {
                    abc[3] = JOptionPane.showInputDialog("Inserire la coordinata x del punto");
                    abc[4] = JOptionPane.showInputDialog("Inserire la coordinata y del punto");
                }
                case "Parallela" -> {
                    abc[3] = JOptionPane.showInputDialog("Inserire la coordinata x del punto");
                    abc[4] = JOptionPane.showInputDialog("Inserire la coordinata y del punto");
                }
            }
            response = format(command, abc);
            out.println(response);
            JOptionPane.showMessageDialog(null, in.readLine());
        }
    }

    private static String format(String command, String[] abc) {
        String message = command + "§" + abc[0] + "#" + abc[1] + "#" + abc[2];
        if (!abc[3].equals("")) {
            message += "#" + abc[3] + "#" + abc[4];
        }
        return message;
    }
}
