/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.avo.soluzionerette;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 *
 * @author palma
 */
class SingleServer implements Runnable {

    Socket socket;

    public SingleServer(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        PrintWriter out = null;
        try {
            out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String message;
            String[] messageParts;
            String[] parameters;
            String response = null;
            while (!"Quit".equals(message = in.readLine())) {
                messageParts = message.split("§");
                parameters = messageParts[1].split("#");

                switch (messageParts[0]) {
                    case "Esplicita" -> {
                        float[] mq = convert(parameters);
                        response = formatEsplicita(mq);
                    }
                    case "Ortogonale" -> {
                        float[] abc = findOrtogonal(parameters);
                        response = formatAbc(messageParts[0], abc);
                    }
                    case "Parallela" -> {
                        float[] abc = findParallel(parameters);
                        response = formatAbc(messageParts[0], abc);
                    }
                }
                out.println(response);
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    private float[] convert(String[] parameters) {
        float[] mq = new float[2];
        float[] parametersFl = convertToFloat(parameters);
        if (parametersFl[1] == 0) {
            mq[0] = -parametersFl[2] / parametersFl[0];
            mq[1] = Float.MAX_VALUE;
        } else {
            mq[0] = -parametersFl[0] / parametersFl[1];
            mq[1] = -parametersFl[2] / parametersFl[1];
        }
        return mq;
    }

    private float[] findOrtogonal(String[] parameters) {
        float[] abc = new float[3];
        float[] parametersFl = convertToFloat(parameters);
        abc[0] = parametersFl[1];
        abc[1] = -parametersFl[0];
        abc[2] = parametersFl[0] * parametersFl[4] - parametersFl[1] * parametersFl[3];
        return abc;
    }

    private float[] findParallel(String[] parameters) {
        float[] abc = new float[3];
        float[] parametersFl = convertToFloat(parameters);
        abc[0] = parametersFl[0];
        abc[1] = parametersFl[1];
        abc[2] = -parametersFl[0] * parametersFl[3] - parametersFl[1] * parametersFl[4];
        return abc;
    }

    private float[] convertToFloat(String[] parameters) {
        float[] parametersFl = new float[parameters.length];
        for (int i = 0; i < parametersFl.length; i++) {
            parametersFl[i] = Float.parseFloat(parameters[i]);
        }
        return parametersFl;
    }

    private String formatEsplicita(float[] mq) {
        String response = "Esplicita§" + mq[0];
        if (mq[1] != Float.MAX_VALUE) {
            response += "#" + mq[1];
        }
        return response;
    }

    private String formatAbc(String command, float[] abc) {
        return command + "§" + abc[0] + "#" + abc[1] + "#" + abc[2];
    }

}
