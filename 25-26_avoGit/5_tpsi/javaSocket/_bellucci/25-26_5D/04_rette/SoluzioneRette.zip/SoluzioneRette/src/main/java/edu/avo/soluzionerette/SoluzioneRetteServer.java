/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package edu.avo.soluzionerette;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author palma
 */
public class SoluzioneRetteServer {

    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(60000);
        Socket socket;
        SingleServer singleserver;
        Thread thread;
        int i = 0;
        while (true) {
            socket = server.accept();
            singleserver = new SingleServer(socket);
            thread = new Thread(singleserver);
            thread.start();
        }
    }
}
