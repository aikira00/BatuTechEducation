/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package edu.avo.eserciziodate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

/**
 *
 * @author palma
 */
public class EsercizioDateMultiServer {

    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(60000);
        SingleServer singleServer;
        Thread thread;
        while (true) {
            Socket socket = server.accept();
            singleServer = new SingleServer(socket);
            thread = new Thread(singleServer);
            thread.start();
        }
    }
}
