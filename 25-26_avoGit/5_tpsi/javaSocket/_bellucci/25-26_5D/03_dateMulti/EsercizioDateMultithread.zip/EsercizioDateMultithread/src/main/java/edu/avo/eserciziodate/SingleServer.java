/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.avo.eserciziodate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

/**
 *
 * @author MULTI01
 */
public class SingleServer implements Runnable{
    private Socket socket;

    public SingleServer(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        PrintWriter out = null;
        try {
            out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String message;
            String[] parts;
            String response;
            while (!"Quit".equals(message = in.readLine())) {
                parts = message.split(" ");
                LocalDate data = LocalDate.parse(parts[1]);
                response = parts[0] + " ";
                switch (parts[0]) {
                    case "DaysToNow" -> {
                        long days = data.until(LocalDate.now(), ChronoUnit.DAYS);
                        response += days;
                    }
                    case "DayOfWeek" -> {
                        String name = data.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ITALY);
                        response += name;
                    }
                    case "DaysBetween" -> {
                        LocalDate secondData = LocalDate.parse(parts[2]);
                        long days = data.until(secondData, ChronoUnit.DAYS);
                        response += days;
                    }
                }
                out.println(response);
            }   in.close();
            out.close();
            socket.close();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        } 
    }
    
    
}
