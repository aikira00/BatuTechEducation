/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.avo.eserciziodate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JOptionPane;

/**
 *
 * @author palma
 */
public class EsercizioDateClient {

    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 60000);
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String[] commands = {"DaysToNow", "DayOfWeek", "DaysBetween", "Quit"};
        boolean error;
        String command = null;
        while (!"Quit".equals(command = JOptionPane.showInputDialog("Inserire il comando"))) {
            error = false;
            switch (command) {
                case "DaysToNow" -> {
                    command = "DaysToNow " + JOptionPane.showInputDialog("Inseire la data");
                }
                case "DayOfWeek" -> {
                    command = "DayOfWeek " + JOptionPane.showInputDialog("Inserire la data");
                }
                case "DaysBetween" -> {
                    command = "DaysBetween " + JOptionPane.showInputDialog("Inserire la prima data");
                    command += " " + JOptionPane.showInputDialog("Inserire la seconda data");
                }
                default -> {
                    error = true;
                    JOptionPane.showMessageDialog(null, "Comando errato");
                }
            }
            if (!error) {
                out.println(command);
                JOptionPane.showMessageDialog(null, in.readLine());
            }
        }
        in.close();
        out.close();
        socket.close();
    }
}
