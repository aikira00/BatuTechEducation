package elfi;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class listaRegalo {
    private List<String> magazzino = new ArrayList<>(); //array di prodotti
    private int max_magazzino;
    private int indexTwinky = 0;
    private int countBlinky = 0;
    private List<Blinky> blinkyList = new ArrayList<>();
    
    
    public listaRegalo(int max_magazzino) {
        this.max_magazzino = max_magazzino;
    }

    public listaRegalo(int max_magazzino, List<Blinky> blinkyList) {
        this.max_magazzino = max_magazzino;
        this.blinkyList = blinkyList;
    }

    //Produttore
    public synchronized boolean produce(Twinky twinky) {
        while (magazzino.size() == max_magazzino && indexTwinky < twinky.getnTwinky() && !blinkyList.isEmpty()) {
            try {
                System.out.println("Magazzino è pieno.\n");
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(listaRegalo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        if(blinkyList.isEmpty()){
            return false;
        }

        if (indexTwinky == twinky.getnTwinky() && magazzino.getLast().equals("stop") == false) {
            magazzino.add("stop");
        }

        if (indexTwinky > 0) {
            for (int i = 0; i < magazzino.size(); i++) {
                if (magazzino.get(i).equals("stop")) {
                    notifyAll();
                    return false;
                }

            }

        }
        magazzino.add("regalo " + indexTwinky);
        twinky.getProdottoList().add("regalo " + indexTwinky);
        System.out.println("Il regalo prodotto è: " + "regalo " + indexTwinky + "\n");
        indexTwinky++;
        notifyAll();
        return true;
    }

    //Consumatore
    public synchronized boolean spedisci(Blinky blinky) { //se questo metodo è in uso il metodo produce non può essere richiamato e viceversa
        while (magazzino.isEmpty() && countBlinky < blinky.getnBlinky()) {
            try {
                System.out.println("Magazzino è vuoto.\n");
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(listaRegalo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        if(countBlinky == blinky.getnBlinky()){
            blinkyList.remove(blinky);
            notifyAll();
            return false;
        }
        
        for (int i = 0; i < magazzino.size(); i++) {
            if (magazzino.get(i).equals("stop")) {
                blinkyList.remove(blinky);
                notifyAll();
                return false;
            }
        }
        
        blinky.getSpeditoList().add(magazzino.getFirst());
        System.out.println("Il regalo spedito è: " + magazzino.getFirst() + "\n");
        magazzino.removeFirst();
        countBlinky++;
        notifyAll();
        return true;
    }

    public List<Blinky> getBlinkyList() {
        return blinkyList;
    }

    public void setBlinkyList(List<Blinky> blinkyList) {
        this.blinkyList = blinkyList;
    }

    public List<String> getMagazzino() {
        return magazzino;
    }

}
