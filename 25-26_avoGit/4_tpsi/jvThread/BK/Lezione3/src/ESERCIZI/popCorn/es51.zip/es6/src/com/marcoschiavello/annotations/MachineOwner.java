package com.marcoschiavello.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotazione che indica una un istaza di una classe annotata con questa annotazione puo aggiungere popcorn alla macchina
 *
 * @author Marco Schiavello
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface MachineOwner { }
