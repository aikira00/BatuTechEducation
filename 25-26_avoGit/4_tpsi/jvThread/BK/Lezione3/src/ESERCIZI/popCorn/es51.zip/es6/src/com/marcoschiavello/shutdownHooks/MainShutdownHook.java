package com.marcoschiavello.shutdownHooks;

import com.marcoschiavello.Macchina;

/**
 * Shutdown hook per gestire la conclusione della applicazione, prende una macchian in modo da teminarla con il metodo prestabilito in modo gracefully
 *
 * @author Marco Shciavello
 */
public class MainShutdownHook extends Thread{
    private Macchina macchina;

    public MainShutdownHook(Macchina macchina) { this.macchina = macchina; }

    @Override
    public void run() { this.macchina.switchOff(); }

}
