package com.marcoschiavello;

import com.marcoschiavello.annotations.MachineOwner;

/**
 * Classe che identifica una macchina di popcorn che sarà usata da N consumatori e gestita e riempita da 1 a N servitori
 *
 * @author Marco Shciavello
 */
public class Macchina {
    /**
     * grammi di popcorn dentro la macchina
     */
    private int gramsOfPopcorn;
    /**
     * flag che indica se la macchina è attiva o meno
     */
    private boolean active;
    /**
     * flag che indica se la macchina deve essere riempita da un servitore
     */
    private boolean needsTobeRefilled;

    /**
     * costruttore completo che crea una macchiana di popcorn
     *
     * @param gramsOfPopcorn grammi di popcorn iniziali
     */
    public Macchina(int gramsOfPopcorn) {
        this.gramsOfPopcorn = gramsOfPopcorn;
        this.active = true;
        this.needsTobeRefilled = false;
    }

    /**
     * getter di gramsOfPopcorn sincronizzato sull'oggetto macchina corrente
     */
    public synchronized int getGramsOfPopcorn() { return this.gramsOfPopcorn; }

    /**
     * getter del flag active
     */
    public boolean isActive() { return this.active; }

    /**
     * metodo che mette a false l'attributo active
     */
    public void switchOff(boolean verbose) {
        this.active = false;
        if(verbose)
            System.out.println("La macchina dei popcorn si sta spegnendo");
    }

    /**
     * scorciatoia del metodo che mette a false l'attributo active
     */
    public void switchOff() { this.switchOff(true); }

    /**
     * getter del flag needsTobeRefilled
     */
    public boolean isNeedsTobeRefilled() { return this.needsTobeRefilled; }

    /**
     * metodo sincronizzato sull'oggetto macchina corrente che preleva una quantita N di popcorn dalla macchina dove N è un numero preso come parametro
     *
     * @param amount quantita di popcorn da prendere
     */
    public boolean pickPopcorn(int amount) {
        this.needsTobeRefilled = amount > this.gramsOfPopcorn;

        this.gramsOfPopcorn -= (amount * (this.needsTobeRefilled ? 0 : 1));
        return !this.needsTobeRefilled;
    }

    /**
     * metodo sincronizzato sull'oggetto macchina corrente che aggiunge una quantita N di popcorn nella macchina dove N è un numero preso come parametro
     * l'azione di aggiunta è controllata e puo essere fatto solo da istanze di classe che sono annotate con l'annotazione {@link MachineOwner}
     *
     * @param popcorn quantita di popcorn da aggiugere
     * @param depositer istanza dell'oggetto che vuole aggiungere i popcorn
     */
    public void addGramsOfPopcorn(int popcorn, Object depositer) {
        if(depositer.getClass().isAnnotationPresent(MachineOwner.class))
            this.gramsOfPopcorn += popcorn;
    }
}

