package com.marcoschiavello;

/**
 * Classe che indica un consumatore che prende i popcorn dalla machcina ogni secondo e sincrozinna la stampa e presa dei popcorn sull'oggetto della macchina
 * se la richiesta di popcorn e piu grande della disponibilita della macchina allora verra chiamato wait() che lasciera il lock all'servitore che riempirà la machina
 *
 * @author Marco Schiavello
 */
public class Consumatore {
    /**
     * macchiina a cui fa riferimento il consumatore
     */
    private Macchina macchina;
    /**
     * thread che esegue le azzioni del consumatore in modo concorente
     */
    private Thread consumatoreThread;
    /**
     * flag che dice se sampre messaggi sullo stato dell'eseguzione
     */
    private boolean verbose;

    /**
     * costruttore completo che crea un consumatore
     *
     * @param macchina macchiina a cui fa riferimento il consumatore
     * @param nome nome del thread del consumatore
     * @param verbose flag che dice se sampre messaggi sullo stato dell'eseguzione
     */
    public Consumatore(Macchina macchina, String nome, boolean verbose) {
        this.macchina = macchina;
        this.verbose = verbose;
        this.consumatoreThread = new Thread(() -> {
            while(macchina.isActive()) {
                synchronized(macchina) {
                    while(!macchina.pickPopcorn(100)) {
                        try { macchina.wait(); } catch(InterruptedException e) { }
                    }

                    if(this.verbose)
                        System.out.println(nome + " ha preso 100 grammi di popcorn, rimanenti = " + macchina.getGramsOfPopcorn() + "g");
                }

                try { consumatoreThread.sleep(1000); } catch(InterruptedException e) { }
            }
        }, nome);

    }

    /**
     * costruttore parziale che crea un consumatore
     *
     * @param macchina macchiina a cui fa riferimento il consumatore
     * @param nome nome del thread del consumatore
     */
    public Consumatore(Macchina macchina, String nome) { this(macchina, nome, true); }

    /**
     * setter di verbose
     *
     * @return valore di verbose
     */
    public boolean isVerbose() {return this.verbose; }

    /**
     * getter di verbose
     */
    public void setVerbose(boolean verbose) { this.verbose = verbose; }

    /**
     * matodo wrapper di {@link Thread#start()}
     */
    public void start() { this.consumatoreThread.start(); }
}
