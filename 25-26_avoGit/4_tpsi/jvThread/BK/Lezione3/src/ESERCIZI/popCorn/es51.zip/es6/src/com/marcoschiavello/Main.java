package com.marcoschiavello;

import com.marcoschiavello.shutdownHooks.MainShutdownHook;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static int NUM_USERS = 2;

    public static void main(String[] args) throws InterruptedException {
        Macchina macchina = new Macchina(1000); // crea una macchina con un valore di popcorn di base di 1000g
        Servitore servitore = new Servitore(macchina); // crea un servitore che continuera a riempire la macchina di 1000g ogni volta che i popcorn dentro la macchina non sono sufficenti per soddisfare una richiesta
        List<Consumatore> consumatori = new ArrayList<>(); // lista di consumatori

        servitore.start(); // parte il servitore
        for(int i = 0; i < NUM_USERS; i++) {
            consumatori.add(new Consumatore(macchina, "consumatore-" + i)); // crea un servitore e lo aggiunge alla lista
            consumatori.get(i).start(); // fa partire il servitore
        }

        Thread.currentThread().sleep(30000); // fa continuare il programma per 30 secondi
        macchina.switchOff(false); //spegne la macchina dopo i 30 secondi
        Runtime.getRuntime().addShutdownHook(new MainShutdownHook(macchina)); // aggiunge uno shutdown hook per la gestione della chiussura del programma
    }
}
