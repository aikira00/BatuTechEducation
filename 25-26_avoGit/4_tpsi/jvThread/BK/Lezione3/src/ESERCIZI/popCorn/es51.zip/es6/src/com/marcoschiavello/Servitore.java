package com.marcoschiavello;

import com.marcoschiavello.annotations.MachineOwner;

/**
 * Classe che identifica un servitore che controlla ogni 100 millisecondi se la macchian deve essere riempite se si allora la riempira con il suddetto metodo
 *
 * @author Marco Schiavello
 */
@MachineOwner
public class Servitore {
    /**
     * macchiina a cui fa riferimento il servitore
     */
    private Macchina macchina;
    /**
     * thread che esegue le azzioni del servitore in modo concorente
     */
    private Thread servitoreThread;
    /**
     * flag che dice se sampre messaggi sullo stato dell'eseguzione
     */
    private boolean verbose;

    /**
     * costruttore completo che crea un servitore
     *
     * @param macchina macchiina a cui fa riferimento il servitore
     * @param verbose flag che dice se sampre messaggi sullo stato dell'eseguzione
     */
    public Servitore(Macchina macchina, boolean verbose) {
        this.macchina = macchina;
        this.verbose = verbose;
        this.servitoreThread = new Thread(() -> {
            while(macchina.isActive()) {
                if(macchina.isNeedsTobeRefilled()) {
                    synchronized (macchina) {
                        this.macchina.addGramsOfPopcorn(1000, this);
                        if(this.verbose)
                            System.out.println("Il servitore sta riempiendo la macchina aspetta ...");
                        try { servitoreThread.sleep(2000); } catch(InterruptedException e) { }
                        macchina.notifyAll();
                    }
                }

                try { servitoreThread.sleep(100); } catch(InterruptedException e) { }
            }
        });

        this.servitoreThread.setDaemon(true);
    }

    /**
     * costruttore parziale che crea un servitore
     *
     * @param macchina macchiina a cui fa riferimento il servitore
     */
    public Servitore(Macchina macchina) { this(macchina, true); }

    /**
     * setter di verbose
     *
     * @return valore di verbose
     */
    public boolean isVerbose() {return this.verbose; }

    /**
     * getter di verbose
     */
    public void setVerbose(boolean verbose) { this.verbose = verbose; }

    /**
     * matodo wrapper di {@link Thread#start()}
     */
    public void start() { this.servitoreThread.start(); }
}
