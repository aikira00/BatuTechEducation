/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esercizio5thread;

/**
 *
 * @author palma
 */
public interface IObserver {
    public void mostra(double livello);
}
