/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esercizioparcheggio;

/**
 *
 * @author Sistinformatici PC 4
 */
public class ObserverAuto implements IObserverAuto{
    public void fineSimulazione(String targa){
        System.out.println("Fine simulazione: "+targa);
    }
}
