/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esercizioparcheggio;

import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author Sistinformatici PC 4
 */
public class Parcheggio {
    private IObserverParcheggio observer;
    private Semaphore semaforo;
    private int capienza;
    private int occupati;
    
    public Parcheggio(int capienza, IObserverParcheggio observer){
        this.capienza = capienza;
        this.observer = observer;
        occupati = 0;
        semaforo = new Semaphore(capienza,true);
    }
    
    public void entra(String targa){
        observer.aggiornaStatoMacchina("In ingresso: ", targa);
        try {
            semaforo.acquire();
        } catch (InterruptedException ex) {
            Logger.getLogger(Parcheggio.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        occupati++;
        observer.aggiornaStatoMacchina("Parcheggiato: ", targa);
        observer.aggiornaPosti(occupati, capienza-occupati);
       
    }
    
    public void esce(String targa){
        semaforo.release();
        occupati--;
        observer.aggiornaStatoMacchina("In uscita: ", targa);
        observer.aggiornaPosti(occupati, capienza-occupati);
  
    }
    
}
