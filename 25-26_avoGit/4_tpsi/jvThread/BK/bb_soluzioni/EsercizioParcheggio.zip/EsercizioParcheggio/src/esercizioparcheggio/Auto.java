/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esercizioparcheggio;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sistinformatici PC 4
 */
public class Auto extends Thread{
    private Parcheggio parcheggio;
    private String targa;
    private IObserverAuto observer;

    public Auto(Parcheggio parcheggio, String targa, IObserverAuto observer) {
        this.parcheggio = parcheggio;
        this.targa = targa;
        this.observer = observer;
    }
    
    
    public void run(){
        Random random = new Random();
        
        for(int i = 0; i<10; i++){
            try {
                Thread.sleep(random.nextInt(3000, 5001));
            } catch (InterruptedException ex) {
                Logger.getLogger(Auto.class.getName()).log(Level.SEVERE, null, ex);
            }
            parcheggio.entra(targa);
            
            try {
                Thread.sleep(random.nextInt(1000, 3001));
            } catch (InterruptedException ex) {
                Logger.getLogger(Auto.class.getName()).log(Level.SEVERE, null, ex);
            }
            parcheggio.esce(targa);
        }
        
        observer.fineSimulazione(targa);
        
    }
    
    
    
    
}
