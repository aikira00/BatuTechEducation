/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esercizioparcheggio;

/**
 *
 * @author Sistinformatici PC 4
 */
public class ObserverParcheggio implements IObserverParcheggio{

    @Override
    public void aggiornaStatoMacchina(String stato, String targa) {
        System.out.println(stato+targa);
    }

    @Override
    public void aggiornaPosti(int occupati, int liberi) {
         System.out.println("Posti occupati: "+occupati+ " Posti liberi:  "+liberi);
    }
}
