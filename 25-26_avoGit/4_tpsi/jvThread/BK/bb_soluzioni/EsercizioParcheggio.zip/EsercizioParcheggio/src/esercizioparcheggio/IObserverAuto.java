/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package esercizioparcheggio;

/**
 *
 * @author Sistinformatici PC 4
 */
public interface IObserverAuto {
    void fineSimulazione(String targa);
}
