/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esercizioparcheggio;

/**
 *
 * @author Sistinformatici PC 4
 */
public interface IObserverParcheggio {
   void aggiornaStatoMacchina(String stato, String targa);
   void aggiornaPosti(int occupati,int liberi);
}
