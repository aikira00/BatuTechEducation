/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package esercizioparcheggio;

/**
 *
 * @author Sistinformatici PC 4
 */
public class EsercizioParcheggio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        IObserverParcheggio observerP = new ObserverParcheggio();
        IObserverAuto observerA = new ObserverAuto();
        
        Parcheggio parcheggio = new Parcheggio(5, observerP);
        
        for (int i = 1; i < 21; i++) {
            Auto auto = new Auto(parcheggio,"Auto "+i , observerA);
            auto.start();
        }
        
        
    }
    
}
