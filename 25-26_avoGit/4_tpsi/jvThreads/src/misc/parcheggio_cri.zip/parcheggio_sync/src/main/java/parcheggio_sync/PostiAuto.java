/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcheggio_sync;

/**
 *
 * @author cristina
 */
public class PostiAuto {
    
    private int posti_auto_liberi;
    private int posti_totali;
    private IObserverPostiAuto observer;
    
    public PostiAuto(int posti, IObserverPostiAuto observer){
        this.posti_totali = posti;
        this.posti_auto_liberi = posti;
        this.observer = observer;
    }
    
    public synchronized void entra(){
        while(this.posti_auto_liberi == 0){
            try{
                wait();
            }
            catch (InterruptedException e){
                throw new RuntimeException();
            }
        }
        this.posti_auto_liberi--;
        observer.update_posti("Posto occupato", this.posti_auto_liberi, this.posti_totali - this.posti_auto_liberi);
    }
    
    public synchronized void esci(){
        this.posti_auto_liberi++;
        observer.update_posti("Posto liberato", this.posti_auto_liberi, this.posti_totali - this.posti_auto_liberi);
        notifyAll();
    }
    
}
