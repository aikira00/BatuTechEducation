/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package parcheggio_sync;

/**
 *
 * @author cristina
 */
public interface IObserverPostiAuto {
    
    public void update_posti(String status, int p_free, int p_busy);
    
}
