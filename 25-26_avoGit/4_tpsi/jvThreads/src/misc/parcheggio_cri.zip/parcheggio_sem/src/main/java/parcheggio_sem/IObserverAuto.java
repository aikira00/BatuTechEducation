/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package parcheggio_sem;

/**
 *
 * @author cristina
 */
public interface IObserverAuto {
    
    public void update_auto(String targa, String status);
    
}
