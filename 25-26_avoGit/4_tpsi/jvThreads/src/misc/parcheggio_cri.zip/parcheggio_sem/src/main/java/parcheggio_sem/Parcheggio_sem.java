/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package parcheggio_sem;

import java.util.Random;
/**
 *
 * @author cristina
 */
public class Parcheggio_sem {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        ObserverPostiAuto observer_p = new ObserverPostiAuto();
        PostiAuto cond_posti = new PostiAuto(5,observer_p);
        int num_macchine = 10;
        Random rnd = new Random();
        int num_ciclo = 3;
        ObserverAuto observer_a = new ObserverAuto();
        for(int i=0; i<num_macchine;i++){
            int targa = rnd.nextInt();
            Auto car = new Auto(cond_posti,observer_a, String.valueOf(targa), num_ciclo);
            car.start();
        }
    }
}
