/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcheggio_sem;

/**
 *
 * @author cristina
 */
public class ObserverAuto implements IObserverAuto{
    
    @Override
    public void update_auto(String targa, String status){
        System.out.println("Auto con targa " + targa + " è " + status);

    }
    
}
