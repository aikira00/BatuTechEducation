/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcheggio_sem;

import java.util.concurrent.Semaphore;

/**
 *
 * @author cristina
 */
public class PostiAuto {
    
    //private int posti_auto_liberi;
    private int posti_totali;
    private IObserverPostiAuto observer;
    private Semaphore p;
    
    public PostiAuto(int posti, IObserverPostiAuto observer){
        this.posti_totali = posti;
        //this.posti_auto_liberi = posti;
        this.observer = observer;
        p = new Semaphore(this.posti_totali);
    }
    
    public  void entra(){
        try{
            p.acquire();
        }
        catch (InterruptedException e){
            throw new RuntimeException();
        }
        //this.posti_auto_liberi--;
        //observer.update_posti("Posto occupato", this.posti_auto_liberi, this.posti_totali - this.posti_auto_liberi);
        observer.update_posti("Posto occupato", p.availablePermits(), this.posti_totali - p.availablePermits());
    
    }
    
    public  void esci(){
        p.release();
        //this.posti_auto_liberi++;
        observer.update_posti("Posto liberato", p.availablePermits(), this.posti_totali - p.availablePermits());
        //notifyAll();
    }
    
}
