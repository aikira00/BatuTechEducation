/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcheggio_sem;

import java.util.Random;

/**
 *
 * @author cristina
 */
public class Auto extends Thread{
    
    private PostiAuto park;
    private IObserverAuto observer;
    private String targa;
    private int ciclo_parcheggio;
    private Random rnd;
    
    public Auto(PostiAuto p, IObserverAuto obs, String t, int c_p){
        this.park = p;
        this.observer = obs;
        this.targa = t;
        this.ciclo_parcheggio = c_p;
        rnd = new Random();
    }
    
    @Override 
    public void run() {
        //ripeti ciclo parcheggia e libera NC volte
        for(int i =0; i<this.ciclo_parcheggio; i++){
            
            
            park.entra();
            observer.update_auto(this.targa, "entrata");
             try{
                Thread.sleep(rnd.nextInt(5000));
            } catch (InterruptedException e){
                 throw new RuntimeException();
            }
            
           
            park.esci();
            observer.update_auto(this.targa, "uscita");
             try{
                Thread.sleep(rnd.nextInt(5000));
            } catch (InterruptedException e){
                 throw new RuntimeException();
            }
        }
        System.out.println("Sono: " + this.targa + " ho finito il giro, ciao!");
    }
    
}
