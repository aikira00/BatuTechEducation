/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcheggio_sem;

/**
 *
 * @author cristina
 */
public class ObserverPostiAuto implements IObserverPostiAuto{
    
    @Override
    public void update_posti(String status, int p_free, int p_busy){
        System.out.println(status + " posti ancora liberi: " + p_free + " posti occupati: " + p_busy);
    }
    
}
