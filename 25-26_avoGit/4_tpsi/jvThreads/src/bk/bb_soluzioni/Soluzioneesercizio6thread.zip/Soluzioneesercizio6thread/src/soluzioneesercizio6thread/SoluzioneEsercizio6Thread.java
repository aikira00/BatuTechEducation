/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soluzioneesercizio6thread;

/**
 *
 * @author palma
 */
public class SoluzioneEsercizio6Thread {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        IObserver observer=new Observer();
        //Progetto non era necessario fosse un thread
        //e non è necessario in questo caso attenderne la fine
        Progetto progetto=new Progetto(observer);
        progetto.start();
        //progetto.join();
    }
    
}
