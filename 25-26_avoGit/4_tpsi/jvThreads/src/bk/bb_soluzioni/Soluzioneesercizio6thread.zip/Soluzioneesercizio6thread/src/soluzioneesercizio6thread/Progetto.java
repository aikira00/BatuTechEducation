/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soluzioneesercizio6thread;

/**
 *
 * @author palma
 */
public class Progetto extends Thread{
    
    private int durata;
    private IObserver observer;

    public Progetto(IObserver observer) {
        this.observer = observer;
        durata=0;
    }
    
    @Override
    public void run(){        
        try {
            Attivita attivitaA=new Attivita('A',5,observer);
            Attivita attivitaC=new Attivita('C',6,observer);
            attivitaA.start();
            attivitaC.start();
            attivitaA.join();
            attivitaC.join();
            //si potevano riutilizzare le due variabili precedenti
            //ma per chiarezza meglio dichiararne due nuove
            Attivita attivitaD=new Attivita('D',6,observer);
            Attivita attivitaE=new Attivita('E',2,observer);
            
            attivitaD.start();
            attivitaE.start();
            attivitaD.join();
            attivitaE.join();
            //supponendo di non sapere i tempi di esecuzione dei 
            //thread
            durata=Math.max(attivitaD.getDurata()+attivitaA.getDurata(),
                    attivitaC.getDurata()+attivitaE.getDurata());
            observer.mostra('P', durata);
        } catch (InterruptedException ex) {
            throw new RuntimeException(ex);
        }
    }
}
