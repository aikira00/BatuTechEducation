/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soluzioneesercizio6thread;

/**
 *
 * @author palma
 */
public class Observer implements IObserver{

    @Override
    public void mostra(char nomeThread, int durata) {
        System.out.println("Nome: "+nomeThread+" Tempo impiegato: "+durata);
    }
    
}
