/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soluzioneesercizio6thread;

/**
 *
 * @author palma
 */
public interface IObserver {
    void mostra (char nomeThread, int durata);
}
