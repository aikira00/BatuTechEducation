/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soluzioneesercizio6thread;

/**
 *
 * @author palma
 */
public class Attivita extends Thread{
    
    private char nomeThread;
    private int durata;
    private IObserver observer;

    public Attivita(char nomeThread, int durata, IObserver observer) {
        this.nomeThread = nomeThread;
        this.durata = durata;
        this.observer = observer;
    }

    public int getDurata() {
        return durata;
    }
    
    @Override
    public void run(){
        try {
            Thread.sleep(durata*1000);
        } catch (InterruptedException ex) {
            throw new RuntimeException(ex);
        }
        observer.mostra(nomeThread, durata);
    }    
}
