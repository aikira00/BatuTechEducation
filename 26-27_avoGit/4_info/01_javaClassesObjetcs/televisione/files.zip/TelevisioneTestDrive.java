// TelevisioneTestDrive.java
// La classe di prova: ha il main, crea oggetti Televisione e li usa con il punto.
public class TelevisioneTestDrive {
    public static void main(String[] args) {

        Televisione salotto = new Televisione();    // primo oggetto
        salotto.setMarca("Mivar");
        salotto.setPollici(55);

        Televisione cucina = new Televisione();     // secondo oggetto: stessi campi, valori suoi
        cucina.setMarca("Brionvega");
        cucina.setPollici(24);

        // --- a TV spenta i comandi vengono ignorati ---
        salotto.cambiaCanale(5);
        System.out.println("Spenta, canale: " + salotto.getCanale());      // 0

        // --- accendo e uso SOLO quella del salotto ---
        salotto.accendi();
        salotto.cambiaCanale(5);
        salotto.alzaVolume();
        salotto.alzaVolume();
        salotto.alzaVolume();
        System.out.println(salotto.getMarca() + ": canale " + salotto.getCanale()
                           + ", volume " + salotto.getVolume());          // Mivar: canale 5, volume 3

        // quella della cucina non si è accorta di niente: ogni oggetto ha il suo stato
        System.out.println(cucina.getMarca() + ": accesa? " + cucina.isAccesa()
                           + ", volume " + cucina.getVolume());           // Brionvega: accesa? false, volume 0

        // --- i controlli dei metodi ---
        salotto.cambiaCanale(-3);                                          // rifiutato
        System.out.println("Dopo cambiaCanale(-3): " + salotto.getCanale());   // ancora 5

        salotto.attivaMuto();
        System.out.println("Muto? " + salotto.isMuto() + ", volume " + salotto.getVolume());   // true, 3
        salotto.alzaVolume();
        System.out.println("Muto? " + salotto.isMuto() + ", volume " + salotto.getVolume());   // false, 4

        // --- prova a togliere il commento: non compila ---
        // salotto.volume = 500;     // errore: volume has private access in Televisione
    }
}
