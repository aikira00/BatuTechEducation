// Televisione.java
// La classe vera: descrive cosa SA e cosa FA ogni televisione.
// Qui dentro non c'è nessuna TV: gli oggetti nascono nella TestDrive, con new.
class Televisione {

    // --- cosa SA: variabili d'istanza (stato) ---
    // private: fuori da questa classe nessuno può scrivere tv.volume = 500
    private boolean accesa;     // default: false  -> una TV nasce spenta
    private int canale;         // default: 0      -> lo sistemiamo in accendi()
    private int volume;         // default: 0
    private boolean muto;       // default: false
    private String marca;       // default: null   -> finché nessuno chiama setMarca
    private int pollici;        // default: 0

    // --- cosa FA: metodi (comportamento) ---
    // Ogni metodo legge o cambia lo stato di QUESTA televisione, non delle altre.

    public void accendi() {
        accesa = true;
        if (canale == 0) {      // prima accensione: parto dal canale 1
            canale = 1;
        }
    }

    public void spegni() {
        accesa = false;         // canale e volume restano memorizzati, come in una TV vera
    }

    public void cambiaCanale(int n) {
        // due controlli che un attributo public non potrebbe mai fare:
        // 1) a TV spenta non succede niente   2) i canali negativi non esistono
        if (accesa && n >= 1) {
            canale = n;
        }
    }

    public void alzaVolume() {
        if (accesa && volume < 100) {   // il volume si ferma a 100
            volume = volume + 1;
            muto = false;               // toccare il volume toglie il muto
        }
    }

    public void abbassaVolume() {
        if (accesa && volume > 0) {     // e non scende sotto 0
            volume = volume - 1;
            muto = false;
        }
    }

    public void attivaMuto() {
        if (accesa) {
            muto = true;                // il volume NON cambia: così so a quanto tornare
        }
    }

    // --- getter: leggo lo stato senza poterlo rovinare ---
    public boolean isAccesa() { return accesa; }   // per i boolean si usa "is" al posto di "get"
    public int getCanale()    { return canale; }
    public int getVolume()    { return volume; }
    public boolean isMuto()   { return muto; }
    public String getMarca()  { return marca; }
    public int getPollici()   { return pollici; }

    // --- setter: solo per ciò che ha senso impostare da fuori ---
    // Niente setVolume o setCanale: per quelli esistono già i metodi "veri".
    public void setMarca(String m) {
        marca = m;
    }

    public void setPollici(int p) {
        if (p > 0) {                    // una TV da -32 pollici non esiste
            pollici = p;
        }
    }
}
